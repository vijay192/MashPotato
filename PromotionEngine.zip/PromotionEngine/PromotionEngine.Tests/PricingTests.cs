﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace PromotionEngine.Tests
{
    [TestClass]
    public class PricingTests
    {
      

        [TestMethod]
        public void Cashier_OneA_Is50()
        {
            var pricing = new Pricing(GetPricingStrategies());
            var products = new List<Sku>() { 'A' };

            var price = pricing.Checkout(products);

            Assert.AreEqual(50, price);
        }

      

        [TestMethod]
        public void ScenarioA_Test()
        {
            var pricing = new Pricing(GetPricingStrategies());
            var products = new List<Sku>() {'A', 'B', 'C'};

            var price = pricing.Checkout(products);

            Assert.AreEqual(100, price);
        }

        [TestMethod]
        public void ScenarioB_Test()
        {
            var pricing = new Pricing(GetPricingStrategies());
            var products = new List<Sku>()
            {
                'A',
                'A',
                'A',
                'A',
                'A',
                'B',
                'B',
                'B',
                'B',
                'B',
                'C'
            };

            var price = pricing.Checkout(products);

            Assert.AreEqual(370, price);
        }

        [TestMethod]
        public void ScenarioC_Test()
        {
            var pricing = new Pricing(GetPricingStrategies());
            var products = new List<Sku>()
            {
                'A',
                'A',
                'A',
                'B',
                'B',
                'B',
                'B',
                'B',
                'C',
                'D'
            };
            products[8] = 'D';
            var price = pricing.Checkout(products);

            Assert.AreEqual(280, price);
        }

       

        private static List<IPricing> GetPricingStrategies()
        {
            return new List<IPricing>()
            {
                new ScenarioA(),
                new ScenarioB(),
                new ScenarioC(),
                new ScenarioD()
            };
        }
    }
}
