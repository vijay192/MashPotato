﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PromotionEngine
{
    public class Pricing
    {
            private readonly List<IPricing> _pricingStrategies;

            public Pricing(List<IPricing> pricingStrategies)
            {
                _pricingStrategies = pricingStrategies;
            }

            public double Checkout(IList<Sku> products)
            {
            //return (from start in _pricingStrategies let prods = products.Where(p => p == start.Sku) select start.GetPrice(prods.Count())).Sum();
            double result = 0;
            foreach (var strat in _pricingStrategies)
            {
                var prods = products.Where(p => p == strat.Sku);
                result = result + strat.GetPrice(prods.Count());
            }

            return result;
        }
    }
}
