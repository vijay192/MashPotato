﻿using System;
using System.Collections.Generic;
using  System.Threading;

namespace PromotionEngine
{
    class Program
    {
        private static void Main(string[] args)
        {
            var products = new List<Sku>() {'A', 'B', 'C'};
            var products1 = new List<Sku>()
            {
                'A',
                'A',
                'A',
                'A',
                'A',
                'B',
                'B',
                'B',
                'B',
                'B',
                'C'
            };
            var products2 = new List<Sku>()
            {
                'A',
                'A',
                'A',
                'B',
                'B',
                'B',
                'B',
                'B',
                'D',
                'D'
            };

            var pricing = new Pricing(GetPricingStrategies());

            var price1 = pricing.Checkout(products);
            Console.WriteLine($"ScenarioA : {price1}");
            var price2 = pricing.Checkout(products1);
            Console.WriteLine($"ScenarioB : {price2}");
            var price3 = pricing.Checkout(products2);
            Console.WriteLine($"ScenarioC : {price3}");
            Thread.Sleep(1000);
        }

        private static List<IPricing> GetPricingStrategies()
        {
            return new List<IPricing>() {new ScenarioA(), new ScenarioB(), new ScenarioC(), new ScenarioD()};
        }
    }
}
