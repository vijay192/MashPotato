﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PromotionEngine
{
    public abstract class NormalPricing:IPricing
    {
            public abstract Sku Sku { get; }
            protected abstract double Price { get; }

            public double GetPrice(int count)
            {
                return Price * count;
            }
        }
    /// <summary>Price for C</summary>
    public class ScenarioC : NormalPricing
        {
            public override Sku Sku { get; } = 'C';
            protected override double Price { get; } = 20;
        }
    /// <summary>Price for D</summary>
    public class ScenarioD : NormalPricing
        {
            public override Sku Sku { get; } = 'D';
            protected override double Price { get; } = 15;
        }
}
